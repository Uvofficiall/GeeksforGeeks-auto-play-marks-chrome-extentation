chrome.runtime.onInstalled.addListener(() => {
    console.log('GFG Auto Play extension installed');
});